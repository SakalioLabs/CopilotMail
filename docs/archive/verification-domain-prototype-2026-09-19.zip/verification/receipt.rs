use super::{VerificationBinding, VerificationChallenge, VerificationError, VerificationState};
use crate::{PolicyVersionId, VerificationChallengeId, VerificationReceiptId};
use chrono::{DateTime, Utc};

/// Internal immutable receipt row, never a bearer authentication credential.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationReceiptSnapshot {
    pub id: VerificationReceiptId,
    pub challenge_id: VerificationChallengeId,
    pub binding: VerificationBinding,
    pub policy_version_id: PolicyVersionId,
    pub verified_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationReceipt {
    snapshot: VerificationReceiptSnapshot,
}

impl VerificationReceipt {
    /// Derives all authorization-relevant facts from the verified challenge.
    /// The caller must atomically persist this unique receipt with the change;
    /// generating it alone neither commits verification nor authorizes an app.
    pub fn from_verified(
        id: VerificationReceiptId,
        challenge: &VerificationChallenge,
    ) -> Result<Self, VerificationError> {
        let state = challenge.snapshot();
        if id.as_uuid().is_nil()
            || id.as_uuid().is_max()
            || state.state != VerificationState::Verified
        {
            return Err(VerificationError::InvalidSnapshot);
        }
        let verified_at = state
            .verified_at
            .ok_or(VerificationError::InvalidSnapshot)?;
        let expires_at = verified_at
            .checked_add_signed(state.policy.receipt_lifetime())
            .ok_or(VerificationError::InvalidTime)?;
        Ok(Self {
            snapshot: VerificationReceiptSnapshot {
                id,
                challenge_id: state.id,
                binding: state.binding,
                policy_version_id: state.policy_version_id,
                verified_at,
                expires_at,
            },
        })
    }

    /// Rechecks a stored row against the exact persisted challenge. Storage
    /// must also prove that the challenge's policy row is approved and immutable.
    pub fn restore(
        snapshot: VerificationReceiptSnapshot,
        challenge: &VerificationChallenge,
    ) -> Result<Self, VerificationError> {
        let expected = Self::from_verified(snapshot.id, challenge)?;
        if expected.snapshot != snapshot {
            return Err(VerificationError::InvalidSnapshot);
        }
        Ok(expected)
    }

    #[must_use]
    pub fn snapshot(&self) -> VerificationReceiptSnapshot {
        self.snapshot.clone()
    }

    /// Exact-flow and time predicate, not a replacement for live application
    /// authorization or the consuming application's local transaction/ledger.
    #[must_use]
    pub fn valid_for(&self, binding: &VerificationBinding, now: DateTime<Utc>) -> bool {
        &self.snapshot.binding == binding
            && now >= self.snapshot.verified_at
            && now < self.snapshot.expires_at
    }
}
