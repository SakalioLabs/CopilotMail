//! Pure, independently testable rules for application email verification.
//!
//! This module neither authenticates applications nor sends messages. The
//! application layer must lock/recheck authorization and persist transitions,
//! quota, idempotency, audit and outbox atomically. A match is supplied only by
//! a cryptographic verifier, never deserialized from an HTTP request.

mod binding;
mod challenge;
mod policy;
mod receipt;

pub use binding::{VerificationBinding, VerificationPurpose};
pub use challenge::{
    VerificationAttemptOutcome, VerificationChallenge, VerificationChallengeSnapshot,
    VerificationMatch, VerificationState,
};
pub use policy::{VerificationDeliveryState, VerificationPolicy};
pub use receipt::{VerificationReceipt, VerificationReceiptSnapshot};

/// Safe internal rule failures; HTTP adapters must not expose guessing detail.
#[derive(Debug, Clone, Copy, PartialEq, Eq, thiserror::Error)]
pub enum VerificationError {
    #[error("verification policy exceeds a safety bound")]
    InvalidPolicy,
    #[error("verification scope is invalid")]
    InvalidBinding,
    #[error("verification scope does not match")]
    BindingMismatch,
    #[error("verification challenge is not active")]
    NotActive,
    #[error("verification time is invalid")]
    InvalidTime,
    #[error("verification snapshot violates invariants")]
    InvalidSnapshot,
    #[error("verification dispatch has not been reconciled")]
    DispatchUnresolved,
    #[error("verification resend limit reached")]
    ResendLimit,
    #[error("verification resend cooldown has not elapsed")]
    ResendCooldown,
}

#[cfg(test)]
mod tests;
