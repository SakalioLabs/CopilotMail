use super::{
    VerificationBinding, VerificationDeliveryState, VerificationError, VerificationPolicy,
};
use crate::{PolicyVersionId, VerificationChallengeId};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VerificationState {
    Active,
    Verified,
    Expired,
    Locked,
    Cancelled,
}

impl VerificationState {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Active => "active",
            Self::Verified => "verified",
            Self::Expired => "expired",
            Self::Locked => "locked",
            Self::Cancelled => "cancelled",
        }
    }
}

/// Trusted crypto-verifier output. Deliberately not Deserialize/Serialize.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VerificationMatch {
    Matches,
    Mismatch,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VerificationAttemptOutcome {
    Verified { receipt_expires_at: DateTime<Utc> },
    Rejected { locked: bool },
}

/// Internal persistence boundary, not an API DTO. Restoring it always validates
/// counts, state, immutable lifetime and timestamp consistency before use.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationChallengeSnapshot {
    pub id: VerificationChallengeId,
    pub binding: VerificationBinding,
    pub policy_version_id: PolicyVersionId,
    pub policy: VerificationPolicy,
    pub state: VerificationState,
    pub version: u64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
    pub last_dispatch_requested_at: DateTime<Utc>,
    pub failed_attempts: u8,
    pub resend_count: u8,
    pub verified_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationChallenge {
    snapshot: VerificationChallengeSnapshot,
}

impl VerificationChallenge {
    /// Creates rules for a new request. Time and ID are injected so the caller
    /// can use locked database time and persist the same ID on idempotent replay.
    pub fn issue(
        id: VerificationChallengeId,
        binding: VerificationBinding,
        policy_version_id: PolicyVersionId,
        policy: VerificationPolicy,
        now: DateTime<Utc>,
    ) -> Result<Self, VerificationError> {
        let expires_at = now
            .checked_add_signed(policy.challenge_lifetime())
            .ok_or(VerificationError::InvalidTime)?;
        Self::restore(VerificationChallengeSnapshot {
            id,
            binding,
            policy_version_id,
            policy,
            state: VerificationState::Active,
            version: 1,
            created_at: now,
            updated_at: now,
            expires_at,
            last_dispatch_requested_at: now,
            failed_attempts: 0,
            resend_count: 0,
            verified_at: None,
        })
    }

    pub fn restore(snapshot: VerificationChallengeSnapshot) -> Result<Self, VerificationError> {
        let consistent_state = match snapshot.state {
            VerificationState::Active => {
                snapshot.failed_attempts < snapshot.policy.max_failures()
                    && snapshot.updated_at < snapshot.expires_at
                    && snapshot.verified_at.is_none()
            }
            VerificationState::Verified => {
                snapshot.failed_attempts < snapshot.policy.max_failures()
                    && snapshot.verified_at == Some(snapshot.updated_at)
                    && snapshot.updated_at < snapshot.expires_at
            }
            VerificationState::Locked => {
                snapshot.failed_attempts == snapshot.policy.max_failures()
                    && snapshot.updated_at < snapshot.expires_at
                    && snapshot.verified_at.is_none()
            }
            VerificationState::Expired => {
                snapshot.updated_at >= snapshot.expires_at
                    && snapshot.failed_attempts < snapshot.policy.max_failures()
                    && snapshot.verified_at.is_none()
            }
            VerificationState::Cancelled => {
                snapshot.failed_attempts < snapshot.policy.max_failures()
                    && snapshot.updated_at < snapshot.expires_at
                    && snapshot.verified_at.is_none()
            }
        };
        // Every failure/resend is a transition; terminal transitions contribute
        // one more, except Locked which is already the final failed attempt.
        let terminal_increment = u64::from(matches!(
            snapshot.state,
            VerificationState::Verified | VerificationState::Expired | VerificationState::Cancelled
        ));
        let expected_version = 1
            + u64::from(snapshot.failed_attempts)
            + u64::from(snapshot.resend_count)
            + terminal_increment;
        let minimum_dispatch_at = snapshot.created_at.checked_add_signed(
            snapshot.policy.resend_cooldown() * i32::from(snapshot.resend_count),
        );
        if snapshot.id.as_uuid().is_nil()
            || snapshot.id.as_uuid().is_max()
            || snapshot.policy_version_id.as_uuid().is_nil()
            || snapshot.policy_version_id.as_uuid().is_max()
            || snapshot.version != expected_version
            || snapshot.created_at > snapshot.updated_at
            || snapshot
                .created_at
                .checked_add_signed(snapshot.policy.challenge_lifetime())
                != Some(snapshot.expires_at)
            || snapshot.last_dispatch_requested_at < snapshot.created_at
            || snapshot.last_dispatch_requested_at > snapshot.updated_at
            || snapshot.last_dispatch_requested_at >= snapshot.expires_at
            || minimum_dispatch_at
                .is_none_or(|minimum| snapshot.last_dispatch_requested_at < minimum)
            || (snapshot.resend_count == 0
                && snapshot.last_dispatch_requested_at != snapshot.created_at)
            || snapshot.resend_count > snapshot.policy.max_resends()
            || !consistent_state
        {
            return Err(VerificationError::InvalidSnapshot);
        }
        Ok(Self { snapshot })
    }

    #[must_use]
    pub fn snapshot(&self) -> VerificationChallengeSnapshot {
        self.snapshot.clone()
    }

    /// Expiry is effective without waiting for a background cleanup job.
    #[must_use]
    pub fn state_at(&self, now: DateTime<Utc>) -> VerificationState {
        if self.snapshot.state == VerificationState::Active && now >= self.snapshot.expires_at {
            VerificationState::Expired
        } else {
            self.snapshot.state
        }
    }

    fn active_version(
        &self,
        binding: &VerificationBinding,
        now: DateTime<Utc>,
    ) -> Result<u64, VerificationError> {
        if &self.snapshot.binding != binding {
            return Err(VerificationError::BindingMismatch);
        }
        if now < self.snapshot.updated_at {
            return Err(VerificationError::InvalidTime);
        }
        if self.state_at(now) != VerificationState::Active {
            return Err(VerificationError::NotActive);
        }
        // restore fixes version to 1 + failures + resends + terminal step.
        // Policy bounds keep this below 11; there is no unreachable overflow
        // error branch pretending to provide additional safety.
        Ok(self.snapshot.version + 1)
    }

    /// The returned transition has no side effects. Persist it with the attempt,
    /// idempotency result, quota and audit/outbox before disclosing any verdict.
    pub fn record_attempt(
        &mut self,
        binding: &VerificationBinding,
        verdict: VerificationMatch,
        now: DateTime<Utc>,
    ) -> Result<VerificationAttemptOutcome, VerificationError> {
        let version = self.active_version(binding, now)?;
        let outcome = match verdict {
            VerificationMatch::Matches => {
                let receipt_expires_at = now
                    .checked_add_signed(self.snapshot.policy.receipt_lifetime())
                    .ok_or(VerificationError::InvalidTime)?;
                self.snapshot.state = VerificationState::Verified;
                self.snapshot.verified_at = Some(now);
                VerificationAttemptOutcome::Verified { receipt_expires_at }
            }
            VerificationMatch::Mismatch => {
                self.snapshot.failed_attempts += 1;
                let locked = self.snapshot.failed_attempts == self.snapshot.policy.max_failures();
                if locked {
                    self.snapshot.state = VerificationState::Locked;
                }
                VerificationAttemptOutcome::Rejected { locked }
            }
        };
        self.snapshot.updated_at = now;
        self.snapshot.version = version;
        Ok(outcome)
    }

    /// Resend preserves the code, original lifetime and guessing budget. The
    /// caller still needs a transactionally reserved recipient/application quota.
    pub fn request_resend(
        &mut self,
        binding: &VerificationBinding,
        delivery: VerificationDeliveryState,
        now: DateTime<Utc>,
    ) -> Result<(), VerificationError> {
        let version = self.active_version(binding, now)?;
        if !delivery.permits_explicit_resend() {
            return Err(VerificationError::DispatchUnresolved);
        }
        if self.snapshot.resend_count >= self.snapshot.policy.max_resends() {
            return Err(VerificationError::ResendLimit);
        }
        let not_before = self
            .snapshot
            .last_dispatch_requested_at
            .checked_add_signed(self.snapshot.policy.resend_cooldown())
            .ok_or(VerificationError::InvalidTime)?;
        if now < not_before {
            return Err(VerificationError::ResendCooldown);
        }
        self.snapshot.resend_count += 1;
        self.snapshot.last_dispatch_requested_at = now;
        self.snapshot.updated_at = now;
        self.snapshot.version = version;
        Ok(())
    }

    pub fn cancel(
        &mut self,
        binding: &VerificationBinding,
        now: DateTime<Utc>,
    ) -> Result<(), VerificationError> {
        let version = self.active_version(binding, now)?;
        self.snapshot.state = VerificationState::Cancelled;
        self.snapshot.updated_at = now;
        self.snapshot.version = version;
        Ok(())
    }

    /// Materializes expiry for maintenance. API decisions already use state_at;
    /// re-running cleanup on a terminal challenge is a no-op, not a resurrection.
    pub fn expire(&mut self, now: DateTime<Utc>) -> Result<bool, VerificationError> {
        if now < self.snapshot.updated_at {
            return Err(VerificationError::InvalidTime);
        }
        if self.snapshot.state != VerificationState::Active || now < self.snapshot.expires_at {
            return Ok(false);
        }
        let version = self.snapshot.version + 1;
        self.snapshot.state = VerificationState::Expired;
        self.snapshot.updated_at = now;
        self.snapshot.version = version;
        Ok(true)
    }
}
