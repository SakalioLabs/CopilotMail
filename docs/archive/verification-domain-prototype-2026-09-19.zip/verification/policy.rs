use super::VerificationError;
use chrono::TimeDelta;

/// Immutable policy captured when a challenge is issued. Live authorization
/// and aggregate recipient/application quotas are separate transaction checks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct VerificationPolicy {
    ttl_seconds: u16,
    receipt_seconds: u16,
    max_failures: u8,
    max_resends: u8,
    resend_cooldown_seconds: u16,
}

impl Default for VerificationPolicy {
    fn default() -> Self {
        Self {
            ttl_seconds: 300,
            receipt_seconds: 300,
            max_failures: 5,
            max_resends: 3,
            resend_cooldown_seconds: 60,
        }
    }
}

impl VerificationPolicy {
    /// Validates a policy before it can enter a challenge or be restored from
    /// persistence. Callers cannot extend an existing challenge with a new policy.
    pub fn new(
        ttl_seconds: u16,
        receipt_seconds: u16,
        max_failures: u8,
        max_resends: u8,
        resend_cooldown_seconds: u16,
    ) -> Result<Self, VerificationError> {
        if !(60..=600).contains(&ttl_seconds)
            || !(30..=300).contains(&receipt_seconds)
            || !(1..=5).contains(&max_failures)
            || max_resends > 3
            || !(60..=ttl_seconds).contains(&resend_cooldown_seconds)
        {
            return Err(VerificationError::InvalidPolicy);
        }
        Ok(Self {
            ttl_seconds,
            receipt_seconds,
            max_failures,
            max_resends,
            resend_cooldown_seconds,
        })
    }

    #[must_use]
    pub fn challenge_lifetime(self) -> TimeDelta {
        TimeDelta::seconds(i64::from(self.ttl_seconds))
    }

    #[must_use]
    pub fn receipt_lifetime(self) -> TimeDelta {
        TimeDelta::seconds(i64::from(self.receipt_seconds))
    }

    #[must_use]
    pub fn resend_cooldown(self) -> TimeDelta {
        TimeDelta::seconds(i64::from(self.resend_cooldown_seconds))
    }

    #[must_use]
    pub const fn max_failures(self) -> u8 {
        self.max_failures
    }

    #[must_use]
    pub const fn max_resends(self) -> u8 {
        self.max_resends
    }
}

/// Delivery observations are deliberately not verification states. In
/// particular, acceptance by a mail engine never proves mailbox control.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VerificationDeliveryState {
    Queued,
    Dispatching,
    Accepted,
    Delivered,
    Failed,
    Unknown,
}

impl VerificationDeliveryState {
    #[must_use]
    pub const fn permits_explicit_resend(self) -> bool {
        matches!(self, Self::Accepted | Self::Delivered | Self::Failed)
    }
}
