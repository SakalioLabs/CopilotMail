use super::VerificationError;
use crate::{ApplicationId, OrganizationId};
use std::fmt;
use uuid::Uuid;

/// A purpose must additionally be enabled by the application's approved policy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VerificationPurpose {
    EmailAddress,
    Registration,
    AccountRecovery,
    EmailLogin,
}

impl VerificationPurpose {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::EmailAddress => "email_address",
            Self::Registration => "registration",
            Self::AccountRecovery => "account_recovery",
            Self::EmailLogin => "email_login",
        }
    }
}

/// Exact challenge ownership and business-flow binding. The target is a
/// domain-separated keyed reference, not an address or a bare address hash.
#[derive(Clone, PartialEq, Eq)]
pub struct VerificationBinding {
    organization_id: OrganizationId,
    application_id: ApplicationId,
    flow_id: Uuid,
    purpose: VerificationPurpose,
    recipient_reference: [u8; 32],
}

impl fmt::Debug for VerificationBinding {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("VerificationBinding")
            .field("purpose", &self.purpose)
            .finish_non_exhaustive()
    }
}

impl VerificationBinding {
    /// Rejects reserved IDs; flow IDs are random v4 UUIDs supplied by the
    /// trusted business backend. This validates shape, not RNG provenance.
    pub fn new(
        organization_id: OrganizationId,
        application_id: ApplicationId,
        flow_id: Uuid,
        purpose: VerificationPurpose,
        recipient_reference: [u8; 32],
    ) -> Result<Self, VerificationError> {
        let valid_id = |value: Uuid| !value.is_nil() && !value.is_max();
        if !valid_id(organization_id.as_uuid())
            || !valid_id(application_id.as_uuid())
            || !valid_id(flow_id)
            || flow_id.get_version_num() != 4
            || flow_id.get_variant() != uuid::Variant::RFC4122
            || recipient_reference == [0; 32]
        {
            return Err(VerificationError::InvalidBinding);
        }
        Ok(Self {
            organization_id,
            application_id,
            flow_id,
            purpose,
            recipient_reference,
        })
    }

    #[must_use]
    pub const fn organization_id(&self) -> OrganizationId {
        self.organization_id
    }

    #[must_use]
    pub const fn application_id(&self) -> ApplicationId {
        self.application_id
    }

    #[must_use]
    pub const fn flow_id(&self) -> Uuid {
        self.flow_id
    }

    #[must_use]
    pub const fn purpose(&self) -> VerificationPurpose {
        self.purpose
    }

    /// Internal cryptographic binding input; never render or log this value.
    #[must_use]
    pub const fn recipient_reference(&self) -> &[u8; 32] {
        &self.recipient_reference
    }
}
