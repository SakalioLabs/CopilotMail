use super::*;
use crate::{
    ApplicationId, OrganizationId, PolicyVersionId, VerificationChallengeId, VerificationReceiptId,
};
use chrono::{DateTime, TimeDelta, Utc};
use uuid::Uuid;

fn start() -> DateTime<Utc> {
    DateTime::from_timestamp(1_790_000_000, 0).unwrap()
}

fn binding() -> VerificationBinding {
    VerificationBinding::new(
        OrganizationId::from_uuid(Uuid::from_u128(1)),
        ApplicationId::from_uuid(Uuid::from_u128(2)),
        Uuid::from_u128(0x40000000_0000_4000_8000_000000000003),
        VerificationPurpose::EmailAddress,
        [7; 32],
    )
    .unwrap()
}

fn challenge() -> VerificationChallenge {
    VerificationChallenge::issue(
        VerificationChallengeId::from_uuid(Uuid::from_u128(4)),
        binding(),
        PolicyVersionId::from_uuid(Uuid::from_u128(5)),
        VerificationPolicy::default(),
        start(),
    )
    .unwrap()
}

#[test]
fn policy_bounds_are_enforced_at_construction() {
    for parameters in [
        (59, 300, 5, 3, 60),
        (601, 300, 5, 3, 60),
        (300, 29, 5, 3, 60),
        (300, 301, 5, 3, 60),
        (300, 300, 0, 3, 60),
        (300, 300, 6, 3, 60),
        (300, 300, 5, 4, 60),
        (300, 300, 5, 3, 59),
        (300, 300, 5, 3, 301),
    ] {
        let (ttl, receipt, attempts, resends, cooldown) = parameters;
        assert_eq!(
            VerificationPolicy::new(ttl, receipt, attempts, resends, cooldown),
            Err(VerificationError::InvalidPolicy)
        );
    }
    let strict = VerificationPolicy::new(60, 30, 1, 0, 60).unwrap();
    assert_eq!(strict.challenge_lifetime(), TimeDelta::seconds(60));
    assert_eq!(strict.receipt_lifetime(), TimeDelta::seconds(30));
    assert_eq!(strict.max_failures(), 1);
    assert_eq!(strict.max_resends(), 0);
    assert_eq!(strict.resend_cooldown(), TimeDelta::seconds(60));
    assert!(VerificationPolicy::new(600, 300, 5, 3, 600).is_ok());
}

#[test]
fn reserved_bindings_and_nonrandom_flow_shapes_are_rejected() {
    let valid = binding();
    for reserved in [Uuid::nil(), Uuid::max()] {
        assert!(
            VerificationBinding::new(
                OrganizationId::from_uuid(reserved),
                valid.application_id(),
                valid.flow_id(),
                valid.purpose(),
                [7; 32]
            )
            .is_err()
        );
        assert!(
            VerificationBinding::new(
                valid.organization_id(),
                ApplicationId::from_uuid(reserved),
                valid.flow_id(),
                valid.purpose(),
                [7; 32]
            )
            .is_err()
        );
        assert!(
            VerificationBinding::new(
                valid.organization_id(),
                valid.application_id(),
                reserved,
                valid.purpose(),
                [7; 32]
            )
            .is_err()
        );
    }
    for flow in [
        Uuid::from_u128(5),
        Uuid::from_u128(0x40000000_0000_7000_8000_000000000003),
        Uuid::from_u128(0x40000000_0000_4000_0000_000000000003),
    ] {
        assert!(
            VerificationBinding::new(
                valid.organization_id(),
                valid.application_id(),
                flow,
                valid.purpose(),
                [7; 32]
            )
            .is_err()
        );
    }
    assert!(
        VerificationBinding::new(
            valid.organization_id(),
            valid.application_id(),
            valid.flow_id(),
            valid.purpose(),
            [0; 32]
        )
        .is_err()
    );
    assert_eq!(valid.recipient_reference(), &[7; 32]);
    let debug = format!("{valid:?}");
    assert!(!debug.contains(&valid.flow_id().to_string()));
    assert!(!debug.contains("[7, 7"));
    for (purpose, wire) in [
        (VerificationPurpose::EmailAddress, "email_address"),
        (VerificationPurpose::Registration, "registration"),
        (VerificationPurpose::AccountRecovery, "account_recovery"),
        (VerificationPurpose::EmailLogin, "email_login"),
    ] {
        assert_eq!(purpose.as_str(), wire);
    }
}

#[test]
fn every_scope_dimension_is_checked_before_mutation() {
    let b = binding();
    let variants = [
        VerificationBinding::new(
            OrganizationId::from_uuid(Uuid::from_u128(9)),
            b.application_id(),
            b.flow_id(),
            b.purpose(),
            [7; 32],
        ),
        VerificationBinding::new(
            b.organization_id(),
            ApplicationId::from_uuid(Uuid::from_u128(9)),
            b.flow_id(),
            b.purpose(),
            [7; 32],
        ),
        VerificationBinding::new(
            b.organization_id(),
            b.application_id(),
            Uuid::from_u128(0x40000000_0000_4000_8000_000000000009),
            b.purpose(),
            [7; 32],
        ),
        VerificationBinding::new(
            b.organization_id(),
            b.application_id(),
            b.flow_id(),
            VerificationPurpose::AccountRecovery,
            [7; 32],
        ),
        VerificationBinding::new(
            b.organization_id(),
            b.application_id(),
            b.flow_id(),
            b.purpose(),
            [9; 32],
        ),
    ];
    for other in variants {
        let mut value = challenge();
        let before = value.clone();
        let other = other.unwrap();
        assert_eq!(
            value.record_attempt(&other, VerificationMatch::Matches, start()),
            Err(VerificationError::BindingMismatch)
        );
        assert_eq!(
            value.cancel(&other, start()),
            Err(VerificationError::BindingMismatch)
        );
        assert_eq!(
            value.request_resend(&other, VerificationDeliveryState::Accepted, start()),
            Err(VerificationError::BindingMismatch)
        );
        assert_eq!(value, before);
    }
}

#[test]
fn verification_is_single_use_and_delivery_does_not_verify() {
    let mut value = challenge();
    let now = start() + TimeDelta::seconds(60);
    value
        .request_resend(&binding(), VerificationDeliveryState::Delivered, now)
        .unwrap();
    assert_eq!(value.state_at(now), VerificationState::Active);
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, now),
        Ok(VerificationAttemptOutcome::Verified {
            receipt_expires_at: now + TimeDelta::seconds(300)
        })
    );
    let verified = value.clone();
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, now),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Mismatch, now),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        value.cancel(&binding(), now),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        value.request_resend(&binding(), VerificationDeliveryState::Accepted, now),
        Err(VerificationError::NotActive)
    );
    assert!(!value.expire(start() + TimeDelta::seconds(900)).unwrap());
    assert_eq!(value, verified);
    assert_eq!(
        VerificationChallenge::restore(value.snapshot()).unwrap(),
        value
    );
}

#[test]
fn fifth_failure_locks_without_a_sixth_guess() {
    let mut value = challenge();
    for attempt in 1..=5 {
        assert_eq!(
            value.record_attempt(&binding(), VerificationMatch::Mismatch, start()),
            Ok(VerificationAttemptOutcome::Rejected {
                locked: attempt == 5
            })
        );
        assert_eq!(value.snapshot().failed_attempts, attempt);
        assert_eq!(
            VerificationChallenge::restore(value.snapshot()).unwrap(),
            value
        );
    }
    let locked = value.clone();
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, start()),
        Err(VerificationError::NotActive)
    );
    assert_eq!(value.state_at(start()), VerificationState::Locked);
    assert_eq!(value, locked);
}

#[test]
fn resend_never_extends_expiry_or_resets_failures() {
    let mut value = challenge();
    value
        .record_attempt(&binding(), VerificationMatch::Mismatch, start())
        .unwrap();
    let before = value.clone();
    for delivery in [
        VerificationDeliveryState::Queued,
        VerificationDeliveryState::Dispatching,
        VerificationDeliveryState::Unknown,
    ] {
        assert_eq!(
            value.request_resend(&binding(), delivery, start() + TimeDelta::seconds(60)),
            Err(VerificationError::DispatchUnresolved)
        );
        assert_eq!(value, before);
    }
    assert_eq!(
        value.request_resend(
            &binding(),
            VerificationDeliveryState::Accepted,
            start() + TimeDelta::seconds(59)
        ),
        Err(VerificationError::ResendCooldown)
    );
    assert_eq!(value, before);
    for (index, delivery) in [
        VerificationDeliveryState::Accepted,
        VerificationDeliveryState::Failed,
        VerificationDeliveryState::Delivered,
    ]
    .into_iter()
    .enumerate()
    {
        value
            .request_resend(
                &binding(),
                delivery,
                start() + TimeDelta::seconds(60 * (index as i64 + 1)),
            )
            .unwrap();
        let snapshot = value.snapshot();
        assert_eq!(snapshot.failed_attempts, 1);
        assert_eq!(snapshot.expires_at, before.snapshot().expires_at);
        assert_eq!(VerificationChallenge::restore(snapshot).unwrap(), value);
    }
    let exhausted = value.clone();
    assert_eq!(
        value.request_resend(
            &binding(),
            VerificationDeliveryState::Accepted,
            start() + TimeDelta::seconds(240)
        ),
        Err(VerificationError::ResendLimit)
    );
    assert_eq!(value, exhausted);
}

#[test]
fn expiry_is_effective_at_the_exact_deadline_before_cleanup() {
    let mut value = challenge();
    let deadline = value.snapshot().expires_at;
    let before = value.clone();
    assert_eq!(
        value.state_at(deadline - TimeDelta::nanoseconds(1)),
        VerificationState::Active
    );
    assert_eq!(value.state_at(deadline), VerificationState::Expired);
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, deadline),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        value.request_resend(&binding(), VerificationDeliveryState::Failed, deadline),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        value.cancel(&binding(), deadline),
        Err(VerificationError::NotActive)
    );
    assert_eq!(value, before);
    assert!(!value.expire(deadline - TimeDelta::nanoseconds(1)).unwrap());
    assert!(value.expire(deadline).unwrap());
    let expired = value.clone();
    assert!(!value.expire(deadline).unwrap());
    assert_eq!(value, expired);
    assert_eq!(
        VerificationChallenge::restore(value.snapshot()).unwrap(),
        value
    );
}

#[test]
fn time_regression_and_timestamp_overflow_are_atomic_errors() {
    let mut value = challenge();
    let before = value.clone();
    let old = start() - TimeDelta::nanoseconds(1);
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, old),
        Err(VerificationError::InvalidTime)
    );
    assert_eq!(
        value.cancel(&binding(), old),
        Err(VerificationError::InvalidTime)
    );
    assert_eq!(value.expire(old), Err(VerificationError::InvalidTime));
    assert_eq!(value, before);
    assert_eq!(
        VerificationChallenge::issue(
            before.snapshot().id,
            binding(),
            PolicyVersionId::from_uuid(Uuid::from_u128(5)),
            VerificationPolicy::default(),
            DateTime::<Utc>::MAX_UTC
        ),
        Err(VerificationError::InvalidTime)
    );
    let near_end = DateTime::<Utc>::MAX_UTC - TimeDelta::seconds(300);
    let mut end = VerificationChallenge::issue(
        before.snapshot().id,
        binding(),
        PolicyVersionId::from_uuid(Uuid::from_u128(5)),
        VerificationPolicy::default(),
        near_end,
    )
    .unwrap();
    let unchanged = end.clone();
    assert_eq!(
        end.record_attempt(
            &binding(),
            VerificationMatch::Matches,
            DateTime::<Utc>::MAX_UTC - TimeDelta::seconds(1)
        ),
        Err(VerificationError::InvalidTime)
    );
    assert_eq!(end, unchanged);
}

#[test]
fn cancellation_is_terminal_and_snapshot_restore_is_strict() {
    let mut value = challenge();
    value.cancel(&binding(), start()).unwrap();
    assert_eq!(value.state_at(start()), VerificationState::Cancelled);
    assert_eq!(
        value.record_attempt(&binding(), VerificationMatch::Matches, start()),
        Err(VerificationError::NotActive)
    );
    assert_eq!(
        VerificationChallenge::restore(value.snapshot()).unwrap(),
        value
    );
    let base = challenge().snapshot();
    let mutations: &[fn(&mut VerificationChallengeSnapshot)] = &[
        |s| s.id = VerificationChallengeId::from_uuid(Uuid::nil()),
        |s| s.id = VerificationChallengeId::from_uuid(Uuid::max()),
        |s| s.version = 0,
        |s| s.version = u64::MAX,
        |s| s.expires_at += TimeDelta::seconds(1),
        |s| s.created_at += TimeDelta::seconds(1),
        |s| s.updated_at -= TimeDelta::seconds(1),
        |s| s.last_dispatch_requested_at += TimeDelta::seconds(1),
        |s| s.failed_attempts = 6,
        |s| s.resend_count = 4,
        |s| s.state = VerificationState::Verified,
        |s| s.state = VerificationState::Expired,
        |s| s.state = VerificationState::Locked,
        |s| s.verified_at = Some(s.created_at),
        |s| {
            s.resend_count = 1;
            s.version = 2;
        },
    ];
    for mutation in mutations {
        let mut changed = base.clone();
        mutation(&mut changed);
        assert_eq!(
            VerificationChallenge::restore(changed),
            Err(VerificationError::InvalidSnapshot)
        );
    }
    for (state, wire) in [
        (VerificationState::Active, "active"),
        (VerificationState::Verified, "verified"),
        (VerificationState::Expired, "expired"),
        (VerificationState::Locked, "locked"),
        (VerificationState::Cancelled, "cancelled"),
    ] {
        assert_eq!(state.as_str(), wire);
    }
}

#[test]
fn exhaustive_short_operation_traces_preserve_state_invariants() {
    // All 5^6 traces: wrong, correct, resend, cancel, expiry. This is a small
    // model/property check, not a claim to prove concurrent database behavior.
    for mut trace in 0..15_625 {
        let mut value = challenge();
        let original_expiry = value.snapshot().expires_at;
        for step in 0..6 {
            let op = trace % 5;
            trace /= 5;
            let before = value.clone();
            let now = start() + TimeDelta::seconds(step * 60);
            let result = match op {
                0 => value
                    .record_attempt(&binding(), VerificationMatch::Mismatch, now)
                    .map(|_| ()),
                1 => value
                    .record_attempt(&binding(), VerificationMatch::Matches, now)
                    .map(|_| ()),
                2 => value.request_resend(&binding(), VerificationDeliveryState::Accepted, now),
                3 => value.cancel(&binding(), now),
                _ => value.expire(now).map(|_| ()),
            };
            if result.is_err() {
                assert_eq!(value, before);
            }
            let snapshot = value.snapshot();
            assert_eq!(snapshot.expires_at, original_expiry);
            assert!(snapshot.failed_attempts >= before.snapshot().failed_attempts);
            assert!(snapshot.failed_attempts <= snapshot.policy.max_failures());
            assert!(snapshot.resend_count <= snapshot.policy.max_resends());
            assert!(snapshot.version >= before.snapshot().version);
            if before.snapshot().state != VerificationState::Active {
                assert_eq!(value, before);
            }
            assert_eq!(VerificationChallenge::restore(snapshot).unwrap(), value);
        }
    }
}

#[test]
fn receipt_is_bound_to_the_verified_challenge_policy_flow_and_time() {
    let mut value = challenge();
    let receipt_id = VerificationReceiptId::from_uuid(Uuid::from_u128(10));
    assert_eq!(
        VerificationReceipt::from_verified(receipt_id, &value),
        Err(VerificationError::InvalidSnapshot)
    );
    let verified_at = start() + TimeDelta::seconds(4);
    value
        .record_attempt(&binding(), VerificationMatch::Matches, verified_at)
        .unwrap();
    let receipt = VerificationReceipt::from_verified(receipt_id, &value).unwrap();
    let row = receipt.snapshot();
    assert_eq!(row.verified_at, verified_at);
    assert_eq!(row.expires_at, verified_at + TimeDelta::seconds(300));
    assert_eq!(row.policy_version_id, value.snapshot().policy_version_id);
    assert_eq!(row.challenge_id, value.snapshot().id);
    assert!(!receipt.valid_for(&binding(), verified_at - TimeDelta::nanoseconds(1)));
    assert!(receipt.valid_for(&binding(), verified_at));
    assert!(receipt.valid_for(&binding(), row.expires_at - TimeDelta::nanoseconds(1)));
    assert!(!receipt.valid_for(&binding(), row.expires_at));
    let other = VerificationBinding::new(
        binding().organization_id(),
        binding().application_id(),
        binding().flow_id(),
        VerificationPurpose::AccountRecovery,
        [7; 32],
    )
    .unwrap();
    assert!(!receipt.valid_for(&other, verified_at));
    assert_eq!(
        VerificationReceipt::restore(row.clone(), &value).unwrap(),
        receipt
    );
    for id in [Uuid::nil(), Uuid::max()] {
        assert_eq!(
            VerificationReceipt::from_verified(VerificationReceiptId::from_uuid(id), &value),
            Err(VerificationError::InvalidSnapshot)
        );
        let mut changed = value.snapshot();
        changed.policy_version_id = PolicyVersionId::from_uuid(id);
        assert_eq!(
            VerificationChallenge::restore(changed),
            Err(VerificationError::InvalidSnapshot)
        );
    }
    let mutations: &[fn(&mut VerificationReceiptSnapshot)] = &[
        |s| s.expires_at += TimeDelta::seconds(1),
        |s| s.verified_at += TimeDelta::seconds(1),
        |s| s.challenge_id = VerificationChallengeId::from_uuid(Uuid::from_u128(11)),
        |s| s.policy_version_id = PolicyVersionId::from_uuid(Uuid::from_u128(12)),
    ];
    for mutation in mutations {
        let mut changed = row.clone();
        mutation(&mut changed);
        assert_eq!(
            VerificationReceipt::restore(changed, &value),
            Err(VerificationError::InvalidSnapshot)
        );
    }
    let mut changed = value.snapshot();
    changed.verified_at = Some(verified_at - TimeDelta::seconds(1));
    assert_eq!(
        VerificationChallenge::restore(changed),
        Err(VerificationError::InvalidSnapshot)
    );
}

#[test]
fn cleanup_never_overwrites_locked_or_cancelled_state() {
    let mut locked = challenge();
    for _ in 0..5 {
        locked
            .record_attempt(&binding(), VerificationMatch::Mismatch, start())
            .unwrap();
    }
    let mut cancelled = challenge();
    cancelled.cancel(&binding(), start()).unwrap();
    for mut value in [locked, cancelled] {
        let before = value.clone();
        assert!(!value.expire(start() + TimeDelta::seconds(600)).unwrap());
        assert_eq!(value, before);
    }
}
